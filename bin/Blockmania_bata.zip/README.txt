
Sub-folders:

\build		Source directory
		Contains:
		  BCB6 console build project (Blockmania_b6.bpr)
		  BCB6 GUI build project (Blockmania_GUI_b6.bpr)
		  vc2005 console project (Blockmania_console.sln)

\bin		Binary directory
		Contains:
		  BCB6 console and GUI built executables
		  DLL and BPL requires by BCB6 to execute

		NOTE: BCB6 project will output to this folder
		automatically.  The VC2005 project outputs
		to its Debug sub-folder.

